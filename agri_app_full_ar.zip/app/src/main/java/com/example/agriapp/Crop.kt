package com.example.agriapp

data class Crop(
    val id: String,
    val name: String,
    val seasons: List<String>,
    val waterMmPerDay: Double,
    val fertilizerKgPerHectare: Double
)
