package com.example.agriapp

import kotlin.math.round

data class Recommendation(
    val dailyWaterM3: Double,
    val dailyWaterLiters: Double,
    val fertilizerKg: Double
)

object Calculator {
    fun calculate(areaM2: Double, waterMm: Double, fertilizerKgPerHa: Double): Recommendation {
        val litersPerDay = areaM2 * waterMm
        val m3PerDay = litersPerDay / 1000.0
        val fertilizerKg = fertilizerKgPerHa * areaM2 / 10000.0
        return Recommendation(
            dailyWaterM3 = roundTwo(m3PerDay),
            dailyWaterLiters = roundTwo(litersPerDay),
            fertilizerKg = roundTwo(fertilizerKg)
        )
    }

    private fun roundTwo(v: Double) = round(v * 100) / 100.0
}
