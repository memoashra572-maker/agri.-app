package com.example.agriapp

object CropRepository {
    private val crops = listOf(
        Crop("wheat", "قمح", listOf("الشتاء"), waterMmPerDay = 5.0, fertilizerKgPerHectare = 120.0),
        Crop("corn", "ذرة", listOf("الربيع","الصيف"), waterMmPerDay = 7.0, fertilizerKgPerHectare = 180.0),
        Crop("tomato", "طماطم", listOf("الربيع","الصيف"), waterMmPerDay = 8.0, fertilizerKgPerHectare = 200.0)
    )

    fun getAll() = crops
    fun findById(id: String) = crops.find { it.id == id }
    fun findByName(name: String) = crops.find { it.name == name }
}
