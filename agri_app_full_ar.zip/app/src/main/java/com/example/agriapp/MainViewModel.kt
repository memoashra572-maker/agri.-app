package com.example.agriapp

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var area by mutableStateOf("")
    var selectedCropId by mutableStateOf<String?>(null)
    var selectedSeason by mutableStateOf<String?>(null)
    var recommendation by mutableStateOf<Recommendation?>(null)
    val crops = CropRepository.getAll()

    fun calculate() {
        val areaVal = area.toDoubleOrNull() ?: return
        val crop = CropRepository.findById(selectedCropId ?: return) ?: return
        val rec = Calculator.calculate(areaVal, crop.waterMmPerDay, crop.fertilizerKgPerHectare)
        recommendation = rec
    }
}
