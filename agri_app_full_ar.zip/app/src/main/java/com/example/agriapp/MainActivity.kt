package com.example.agriapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalContext
import android.content.Intent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    var screen by remember { mutableStateOf("home") }
    Scaffold(topBar = {
        TopAppBar(title = { Text(text = when(screen) {
            "home" -> "مُرشِّد الري والسماد"
            "calc" -> "احسب الكميات"
            "instr" -> "تعليمات"
            else -> "مُرشِّد الري والسماد"
        }) })
    }) {
        when(screen) {
            "home" -> HomeScreen(onStart = { screen = "calc" }, onInstructions = { screen = "instr" })
            "calc" -> CalculatorScreen(onBack = { screen = "home" })
            "instr" -> InstructionsScreen(onBack = { screen = "home" })
        }
    }
}

@Composable
fun HomeScreen(onStart: ()->Unit, onInstructions: ()->Unit) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = stringResource(id = R.string.home_title), style = MaterialTheme.typography.h5)
        Text("تطبيق يساعد المزارعين يحسبوا كمية المياه والسماد المطلوبة حسب المساحة والمحصول.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onStart) { Text(stringResource(id = R.string.start)) }
            OutlinedButton(onClick = onInstructions) { Text(stringResource(id = R.string.instructions)) }
        }
    }
}

@Composable
fun InstructionsScreen(onBack: ()->Unit) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("كيفية الاستخدام", style = MaterialTheme.typography.h6)
        Text("1. أدخلي المساحة بالمتر المربع.")
        Text("2. اختاري المحصول.")
        Text("3. اضغطي 'احسب الكميات' للحصول على توصية المياه والسماد.")
        Spacer(Modifier.height(8.dp))
        Button(onClick = onBack) { Text("عودة") }
    }
}

import androidx.compose.ui.res.stringResource

@Composable
fun CalculatorScreen(onBack: ()->Unit) {
    val vm = remember { MainViewModel() }
    Column(modifier = Modifier
        .padding(16.dp)
        .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = vm.area,
            onValueChange = { vm.area = it.filter { ch -> ch.isDigit() || ch=='.' } },
            label = { Text(stringResource(id = R.string.area_label)) },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
        )
        Text(stringResource(id = R.string.select_crop))
        vm.crops.forEach { crop ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = vm.selectedCropId == crop.id,
                    onClick = { vm.selectedCropId = crop.id; vm.selectedSeason = crop.seasons.firstOrNull() }
                )
                Text("${'$'}{crop.name} — مواسم: ${'$'}{crop.seasons.joinToString(", ")}")
            }
        }
        Button(onClick = { vm.calculate() }, enabled = vm.area.isNotBlank() && vm.selectedCropId!=null) {
            Text(stringResource(id = R.string.calculate))
        }
        vm.recommendation?.let { rec ->
            Card(elevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(stringResource(id = R.string.result), style = MaterialTheme.typography.h6)
                    Text("ماء يومي: ${'$'}{rec.dailyWaterLiters} لتر (${ '$'}{rec.dailyWaterM3} م³) لكل اليوم")
                    Text("سماد موصى به: ${'$'}{rec.fertilizerKg} كجم للمساحة المدخلة")
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(id = R.string.notes))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onBack) { Text("عودة") }
    }
}
