# AgriAppFullAR

This project is a full Android Studio project skeleton for the AgriApp with Arabic UI and:
- Home screen
- Instructions screen
- Calculator screen (area + crop selection -> water & fertilizer recommendation)

## How to build an APK (debug) in Android Studio
1. Open Android Studio.
2. File -> Open -> select this project's root folder (where settings.gradle is).
3. Let Gradle sync.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. After build, Android Studio will show a link 'locate' to the generated APK.

## Notes
- Minimum SDK is set to 24. You can change it in app/build.gradle.
- If Android Studio prompts to update the Gradle plugin or Kotlin, accept or change versions accordingly.
- To install the APK on your phone, enable 'Install unknown apps' for your file manager and transfer the APK to your device, then open it to install.

If you'd like, I can:
- Guide you step-by-step to generate the APK on your computer and install it on your phone.
- Create an automated CI configuration (GitHub Actions) that can build an APK for you when you push the project.
